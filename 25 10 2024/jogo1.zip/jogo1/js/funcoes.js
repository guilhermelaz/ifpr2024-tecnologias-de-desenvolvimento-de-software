var vet = new Array();
var lin=10;
var col=10;
var largura=80;
var altura=80;
var posCasa="";
var msg=null;
var cont=0;
const robotStart = []; // Posição inicial do robô
const housePosition = []; // Posição da casa
function criaTabela() {
    pai=document.getElementsByTagName("div")[0];
    tb=document.createElement("table");
    tb.setAttribute("border",1);

    for(let i=0;i<lin;i++){
        tr=document.createElement("tr");
        for(let j=0;j<col;j++){
            td=document.createElement("td");
            td.setAttribute("width",largura);
            td.setAttribute("height",altura);
            td.setAttribute("id",(i+","+j));
            tr.appendChild(td);
        }
        if(i==0){
            td=document.createElement("td");
            td.setAttribute("width",largura);
            td.setAttribute("valign","top");
            td.setAttribute("id","comandos");
            td.setAttribute("rowspan",lin);
            tr.appendChild(td);
        }
        tb.appendChild(tr);
    }
     pai.appendChild(tb);
    posicionarElementos();
}
function posicionarElementos(){
    robo=document.createElement("img");
    robo.setAttribute("src","img/robo.png");
    robo.setAttribute("width",largura);
    robo.setAttribute("id","robo");
    robo.setAttribute("height",altura);
    roboCol=Math.floor(Math.random() * ((col-1) - 0 + 1)) + 0;
    roboLin=Math.floor(Math.random() * ((lin-1)/2 - 0 + 1)) + 0;
    robotStart[0]=roboCol;
    robotStart[1]=roboLin;

    casa=document.createElement("img");
    casa.setAttribute("src","img/casa.png");
    casa.setAttribute("width",largura);
    casa.setAttribute("height",altura);
    casaCol=Math.floor(Math.random() * ((col-1) - 0 + 1)) + 0;
    casaLin=Math.floor(Math.random() * ((lin-1) - (lin-1)/2 + 1)+ (lin-1)/2);
    housePosition[0]=casaCol;
    housePosition[1]=casaLin;

    posRobo=roboLin+","+roboCol;
    posCasa=casaLin+","+casaCol;

    cel=document.getElementById(posRobo);
    cel.appendChild(robo);
    cel=document.getElementById(posCasa);
    cel.appendChild(casa);
}
function run() {
    i=0;
    tempo=setInterval(move, 1000);
}
function move(){
    msg=document.getElementById("msg");
    if(i<vet.length) {
        robo = document.getElementById("robo");
        cel = robo.parentElement;
        pos = cel.id;
        pos = pos.split(",");
        switch (vet[i]) {
            case 0:
                pos[1]--;
                break;
            case 1:
                pos[1]++;
                break;
            case 2:
                pos[0]--;
                break;
            case 3:
                pos[0]++;
                break;
        }
        if(pos[0]>=0&&pos[0]<lin&&pos[1]>=0&&pos[1]<col) {
            nova = document.getElementById(pos[0] + "," + pos[1]);
            cel.removeChild(robo);
            nova.appendChild(robo);
            cel = nova;
            i++;

        }
        else {
            msg.innerHTML="posição inválida";
            clearInterval(tempo);

        }
    }
    verificaObjetivo(cel.id);
}
function verificaObjetivo(robo){
   if(robo.localeCompare(posCasa)==0){
       msg.innerHTML="Chegou";
       clearInterval(tempo);

   }
}
function comandos(e) {
    id=parseInt(e.id);
    cel=document.getElementById("comandos");
   switch (id){
       case 0:
           vet.push(0);
           cel.innerHTML+="Esquerda<br>";
           break;
       case 1:
           vet.push(1);
           cel.innerHTML+="Direita<br>";
           break;
       case 2:
           vet.push(2);
           cel.innerHTML+="Acima<br>";
           break;
       case 3:
           vet.push(3);
           cel.innerHTML+="Abaixo<br>";
           break;
   }
}
