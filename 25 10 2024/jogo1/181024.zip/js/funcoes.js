var vet = new Array();
function criaTabela() {
    pai=document.getElementsByTagName("div")[0];
    tb=document.createElement("table");
    tb.setAttribute("border",1);
    let lin=10;
    let col=10;
    for(let i=0;i<lin;i++){
        tr=document.createElement("tr");
        for(let j=0;j<col;j++){
            td=document.createElement("td");
            td.setAttribute("width",80);
            td.setAttribute("height",80);
            td.setAttribute("id",(i+","+j));
            tr.appendChild(td);
        }
        if(i==0){
            td=document.createElement("td");
            td.setAttribute("width",80);

            td.setAttribute("rowspan",lin);
            tr.appendChild(td);
        }
        tb.appendChild(tr);
    }
     pai.appendChild(tb);
}
function comandos(e) {
    id=parseInt(e.id);
   switch (id){
       case 0:
           vet.push(0);
           break;
       case 1:
           vet.push(1);
           break;
       case 2:
           vet.push(2);
           break;
       case 3:
           vet.push(3);
           break;
   }
}